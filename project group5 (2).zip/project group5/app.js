/*const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const port = 3000;

// create a new Express application

const app = express();


app.use(bodyParser.json());
app.listen(port, () => {
    console.log("server started to listen on " + port);
});  */

const express = require("express");
const bodyParser = require("body-parser");

const app = express();

// parse requests of content-type: application/json
app.use(bodyParser.json());


app.use(bodyParser.urlencoded({ extended: true }));

// simple route
app.get("/", (req, res) => {
  res.json({ message: "Welcome to Nus group5 application." });
});

// set port, listen for requests
require("./backend/routes/member.route.js")(app);

app.listen(3000, () => {
  console.log("Server is running on port 3000.");
});
  
