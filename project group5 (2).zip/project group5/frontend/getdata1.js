function getFromServer() {
    var requestOptions = {
      method: "GET",
      // redirect: "follow",
    };
  
    fetch("http://localhost:3000/member/all", requestOptions)
      .then((response) => response.json())
      .then((data) => {
        var text = "<ul>";
        data.forEach(function (item) {
          text += `<li>
          MembeID: ${item.MemberID} <br>
          GivenName: ${item.GivenName} <br>
          LastName: ${item.LastName} <br>
          nob: ${item.nob} <br>
          Loc: ${item.Loc} <br>
          Budget: ${item.Budget}
          </li>`;
        });
        text += "</ul>";
        $(".mypanel").html(text);
      })
      .catch((error) => console.log("error", error));
  }
  
  function postData() {
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
  
    // Populate this data from e.g. form.
    // var raw = JSON.stringify({
    //   givenName: "dixant",
    //   lastName: "mittal",
    //   nob: 2,
    //   location: "Bugis",
    //   budget : 1000
    // });
   /// const = myForm = document.getElementbyID('myForm');
  //  console.log("this is the data reveived: " + myHeaders);
   /// console.log("my form: " + myForm);
  
    var requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: raw,
    };
  
    fetch("http://localhost:3000/member/add", requestOptions)
      .then((response) => response.text())
      .then((result) => $(".mypanel").html(result))
      .catch((error) => console.log("error", error));
  }
  
  function deleteData() {
    var requestOptions = {
      method: "DELETE",
    };
    fetch("http://localhost:3000/member/delete?MemberID" = '', requestOptions)
      .then((response) => response.text())
      .then((result) => $(".mypanel").html(result))
      .catch((error) => console.log("error", error));
  }