const Member = require("../model/member.model.js");

// Create and Save a new member
exports.create = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  // Create a meber
  const member = new Member({
    MemberID: req.body.MemberId,
    GivenName: req.body.GivenName,
    LastName: req.body.LastName,
    property_type: req.body.property_type,
    Budget: req.body.Budget,
    Loc: req.body.Loc

  });

  // Save Mmebr in the database
  Member.create(member, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the member."
      });
    else res.send(data);
  });
};

// Retrieve all Member from the database.
exports.findAll = (req, res) => {
  Member.getAll((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving members."
      });
    else res.send(data);
  });
};

// Find a single Member with a memberId
exports.findOne = (req, res) => {
  Member.findById(req.params.MemberID, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Customer with id ${req.params.memberID}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving member with MemberID " + req.params.MemberId
        });
      }
    } else res.send(data);
  });
};

// Update a Customer identified by the MemberId in the request
exports.update = (req, res) => {
  // Validate Request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  console.log(req.body);

  Member.updateById(
    req.params.MemberID,
    new Member(req.body),
    (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found member with MemberID ${req.params.MemberID}.`
          });
        } else {
          res.status(500).send({
            message: "Error updating Member with MemberID " + req.params.MemberID
          });
        }
      } else res.send(data);
    }
  );
};

// Delete a member with the specified MemberId in the request
exports.delete = (req, res) => {
  Member.remove(req.params.MemberID, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found member with MemberId ${req.params.MemberID}.`
        });
      } else {
        res.status(500).send({
          message: "Could not delete Member with MemberID " + req.params.MemberID
        });
      }
    } else res.send({ message: `Member was deleted successfully!` });
  });
};

// Delete all Member from the database.
exports.deleteAll = (req, res) => {
  Member.removeAll((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all member."
      });
    else res.send({ message: `All members were deleted successfully!` });
  });
}