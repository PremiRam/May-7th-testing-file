const connection = require("./db.js");

// constructor
const Member= function(member) {
    this.MemberID = member.MemberID;
  this.GivenName= member.GivenName;
  this.LastName = member.LastName;
  this.property_type = member.property_type;
  this.Budget = member.Budget;
  this.Loc = member.Loc;
};

Member.create = (newMember, result) => {
  connection.query("INSERT INTO member SET ?", newMember, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    console.log("created member: ", { MemberID: res.insertId, ...newMember });
    result(null, { id: res.insertId, ...newMember });
  });
};

Member.findById = (MemberID, result) => {
  connection.query(`SELECT * FROM member WHERE MemberID = ${MemberID}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      console.log("found member: ", res[0]);
      result(null, res[0]);
      return;
    }

    // not found memberr with the id
    result({ kind: "not_found" }, null);
  });
};

Member.getAll = result => {
  connection.query("SELECT * FROM member", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log("member: ", res);
    result(null, res);
  });
};

Member.updateById = (MemberID, member, result) => {
  connection.query(
    "UPDATE member SET GivenName= ?, LastName = ?, property_type = ?, Budget = ?, Loc = ?, WHERE MemberID = ?",
    [member.GivenName, member.LastName, member.property_type, member.Budget, member.Loc, MemberID],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }

      if (res.affectedRows == 0) {
        // not found member with the id
        result({ kind: "not_found" }, null);
        return;
      }

      console.log("updated member: ", { MemberID: MemberID, ...member });
      result(null, { MemberID: MemberID, ...member });
    }
  );
};

Member.remove = (MemberID, result) => {
  connection.query("DELETE FROM member WHERE MemberID = ?", MemberID, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found member with the id
      result({ kind: "not_found" }, null);
      return;
    }

    console.log("deleted member with MemberID: ", MemberId);
    result(null, res);
  });
};

Member.removeAll = result => {
  connection.query("DELETE FROM member", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log(`deleted ${res.affectedRows} member`);
    result(null, res);
  });
};

module.exports = Member;