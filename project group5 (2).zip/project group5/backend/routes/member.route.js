module.exports = app => {
    const member = require("../controller/member.controller.js");
  
    // Create a new member
    app.post("/member", member.create);
  
    // Retrieve all member
    app.get("/member", member.findAll);
  
    // Retrieve a single member with memberID
    app.get("/member/:MemberID", member.findOne);
  
    // Update a member with memberId
    app.put("/member/:MemberID", member.update);
  
    // Delete a member with memberrId
    app.delete("/member/:MemberID", member.delete);
  
    // Create a new member
    app.delete("/member", member.deleteAll);
  };